import os
import sys
from CompilationEngine import CompilationEngine

if __name__ == '__main__':
    directory = sys.argv[1]
    if os.path.isdir(directory):
        entries = os.listdir(directory)
        for entry in entries:
            if ".jack" in entry:
                vm_output_file_name = os.path.abspath(os.path.join(directory, entry)) \
                                    .replace(".jack", "") + ".vm"
                CompilationEngine(os.path.abspath(os.path.join(directory, entry)), vm_output_file_name)
    else:
        vm_output_file_name = directory.replace(".jack", "") + ".vm"
        CompilationEngine(directory, vm_output_file_name)
